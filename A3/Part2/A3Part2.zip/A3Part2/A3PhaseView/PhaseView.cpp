#include "PhaseView.h"
#include "Player.h"
#include <iostream>
using namespace std;

PhaseView::PhaseView() {
};
PhaseView::PhaseView(Player* p) {
	//Upon instantiation, attaches itself to a Player
	_phaseSubject = p;
	_phaseSubject->Attach(this);
};
PhaseView::~PhaseView() {
	//Upon destruction, detaches itself from its Player
	_phaseSubject->Detach(this);
};

// Update() is called by Notify() (in the Subject class)
void PhaseView::Update() {
	display();
};

//Displays Phase View. Information will remain constant until next Notify() & Update() call.
void PhaseView::display() {
	system("CLS");
	cout << endl << "---------------------------------------------------------------------- \n"
		"////////////////////// SWITCHING TO PHASE VIEW ///////////////////////  \n"
		"----------------------------------------------------------------------" << endl; 
	cout << endl; cout << endl;

	// Get Data to Display
	string name = _phaseSubject->getName();
	int phase = _phaseSubject->getPhase();
	
	//Set phaseDescriptions
	string phaseDescription = "";
	if (phase == 0) { phaseDescription = "is in REINFORCE phase"; }
	if (phase == 1) { phaseDescription = "is in ATTACK phase"; }
	if (phase == 2) { phaseDescription = "is in FORTIFICATION phase"; }
	if (phase == 3) { phaseDescription = "has completed REINFORCE phase"; }
	if (phase == 4) { phaseDescription = "has completed ATTACK phase"; }
	if (phase == 5) { phaseDescription = "has completed FORTIFICATION phase"; }
	// Print Phase Description
	cout << name << " " << phaseDescription << endl;	cout << "" << endl; cout << endl;
	
	//Showing different information, depending on the phase (Requirement #3 from the assignment):
	if (phase == 1){
		cout << "At the start of the phase, " << name << " owned the following countries: " << endl;
	}
	else if (phase == 4) {
		cout << name << " now owns the following countries. " << endl;
	}
	// Display list of countries	
	_phaseSubject->getCountries(); 

	cout << "" << endl; cout << endl;
	cout << endl << "---------------------------------------------------------------------- \n"
		"     Pressing any key will switch you back to the Main Game View.  \n"
		"----------------------------------------------------------------------" << endl; cout << endl;
	system("PAUSE");
	system("CLS");

};
