#pragma once
#include "PhaseObserver.h"
#include "Player.h"

class PhaseView : public PhaseObserver {
public:
	PhaseView();
	PhaseView(Player* p);
	~PhaseView();
	void Update();
	void display();
//private:       // No need for this to be private.
	Player*_phaseSubject;
};

