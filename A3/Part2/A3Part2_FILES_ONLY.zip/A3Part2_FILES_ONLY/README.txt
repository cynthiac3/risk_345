ASSIGNMENT 3 PART 2

These are only the .cpp and .h files.

The .exe is A3PhaseView.exe.

This program opens multiple console windows to display the "Phase View" (Player is Attacking, etc).
Unfortunately, when I save it to a .exe, that functionality no longer works - even though it works perfectly when opened in Visual Studio.
I suspect it has something to do with the library that was used to produce the multiple consoles.
I may have to demo in person.