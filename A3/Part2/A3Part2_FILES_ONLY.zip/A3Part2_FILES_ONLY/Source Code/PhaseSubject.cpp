#include "PhaseSubject.h"
#include "PhaseObserver.h" //Note: This is already included in PhaseSubject.h, but prof Paquet had it in his code, so will leave it here too.

PhaseSubject::PhaseSubject() {
//	_phaseObservers = new list<PhaseObserver*>;  // implemented in Player.cpp
}
PhaseSubject::~PhaseSubject() {
//	delete _phaseObservers;  // implemented in Player.cpp
}

/*
The methods below were implemented in Player class in order to make PhaseSubject an interface:
*/

//void PhaseSubject::Attach(PhaseObserver* o) {
//	_phaseObservers->push_back(o);
//};
//void PhaseSubject::Detach(PhaseObserver* o) {
//	_phaseObservers->remove(o);
//};
//void PhaseSubject::Notify() {
//	list<PhaseObserver *>::iterator i = _phaseObservers->begin();
//	for (; i != _phaseObservers->end(); ++i)
//		(*i)->Update();
//};
