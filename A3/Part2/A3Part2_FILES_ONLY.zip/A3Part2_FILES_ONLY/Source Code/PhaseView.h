#pragma once
#include "PhaseObserver.h"
#include "Player.h"

class PhaseView : public PhaseObserver {
public:
	PhaseView();
	PhaseView(Player* p);
	~PhaseView();
	void Update();
	void display();

	Player*_phaseSubject; // No need for this to be private.
};

