#pragma once
#include "PhaseObserver.h"
#include <list>
using namespace std;

class PhaseSubject {
public:

	// Made these methods virtual so they could be implemented in Player class.
	virtual void Attach(PhaseObserver* o) = 0;
	virtual void Detach(PhaseObserver* o) = 0;
	virtual void Notify() = 0;

	PhaseSubject();
	~PhaseSubject();
//private: // The following list was also implemented in Player class
	//list<PhaseObserver*> *_phaseObservers;
};
