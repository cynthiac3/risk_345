#pragma once

class PhaseObserver {
public:
	~PhaseObserver();
	virtual void Update() = 0;
protected:
	PhaseObserver();
};
