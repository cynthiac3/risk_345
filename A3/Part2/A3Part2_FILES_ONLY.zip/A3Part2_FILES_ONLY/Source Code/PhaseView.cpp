#include "PhaseView.h"
#include "Player.h"
#include <iostream>
using namespace std;

PhaseView::PhaseView() {
};
PhaseView::PhaseView(Player* p) {
	//Upon instantiation, attaches itself to a Player
	_phaseSubject = p;
	_phaseSubject->Attach(this);
};
PhaseView::~PhaseView() {
	//Upon destruction, detaches itself from its Player
	_phaseSubject->Detach(this);
};

// Update() is called by Notify() (in the Subject class)
void PhaseView::Update() {
	display();
};



/*
The following display() method might be hard to understand. Basically, there are 3 consoles:
1) One MAIN CONSOLE (the normal black screen console where users input information)
2) Two "Coloured" Consoles that only display 1 sentence at a time ("Player 1 IS ATTACKING" etc.)

All 3 console views implement the Observer Pattern (they are all updated by the same Update() call at the same time). 
They are updated once at the start of a phase, and once at the end of a phase.

Originally, I only had the Main Console View (which switched between displaying the main game and 
displaying the "phase" and kept clearing the screen every time Update() was called), but I didn't like that 
because I wanted the phase to be displayed at all times. So that's why the coloured consoles were added. 
*/

//Displays Phase View. Information will remain constant until next Notify() & Update() call.
void PhaseView::display() {
	system("CLS");
	cout << endl << "---------------------------------------------------------------------- \n"
		"////////////////////// SWITCHING TO PHASE VIEW ///////////////////////  \n"
		"----------------------------------------------------------------------" << endl; 
	cout << endl; cout << endl;

	// Get Data to Display
	string name = _phaseSubject->getName();
	int phase = _phaseSubject->getPhase();
	
	// Convert player's name to char so Coloured Console can print it
	int n = name.length();
	char playerName[7];
	strcpy(playerName, name.c_str()); 
	
	//Note: phaseDescription is only used to print to the MAIN CONSOLE (not the coloured consoles)
	string phaseDescription = "";

	// Depending on which phase player is in, different information is updated on the consoles as follows:
	// 0 - Begin Reinforce, 1 - Begin Attack, 2 - Begin Fortify, 3- End Reinforce, 4 - End Attack, 5 - End Fortify
	if (phase == 0) { phaseDescription = "is in REINFORCE phase"; 
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_BLUE);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_GREEN, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_GREEN, " is REINFORCING.");
	}
	if (phase == 1) { phaseDescription = "is in ATTACK phase";
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_RED);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_BLUE, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_BLUE, " is ATTACKING.");
	}
	if (phase == 2) { phaseDescription = "is in FORTIFICATION phase"; 
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_GREEN);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_RED, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_RED, " is FORTIFYING.");
	}
	if (phase == 3) { phaseDescription = "has completed REINFORCE phase"; 
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_BLUE);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_GREEN, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_GREEN, " HAS FINISHED REINFORCING.");
	}
	if (phase == 4) { phaseDescription = "has completed ATTACK phase";
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_RED);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_BLUE, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_BLUE, " HAS FINISHED ATTACKING.");
		}
	if (phase == 5) { phaseDescription = "has completed FORTIFICATION phase"; 
		_phaseSubject->getPhaseConsole()->cls(CConsoleLoggerEx::COLOR_BACKGROUND_GREEN);
		_phaseSubject->getPhaseConsole()->gotoxy(10, 10);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_RED, playerName);
		_phaseSubject->getPhaseConsole()->cprintf(CConsoleLoggerEx::COLOR_WHITE | CConsoleLoggerEx::COLOR_BACKGROUND_RED, " HAS FINISHED FORTIFYING.");
	}


	// Print Phase Description To MAIN CONSOLE (NOT the coloured consoles)
	cout << name << " " << phaseDescription << endl;	cout << "" << endl; cout << endl;
	
	//Showing different information on MAIN CONSOLE, depending on the phase (Requirement #3 from the assignment):
	if (phase == 1){
		cout << "At the start of the phase, " << name << " owned the following countries: " << endl;
		_phaseSubject->getCountries();	// Display list of countries
	}
	else if (phase == 4) {
		cout << name << " now owns the following countries. " << endl;
		_phaseSubject->getCountries();	// Display list of countries
	}

	cout << "" << endl; cout << endl;
	cout << endl << "---------------------------------------------------------------------- \n"
		"     Pressing any key will switch you back to the Main Game View.  \n"
		"----------------------------------------------------------------------" << endl; cout << endl;
	system("PAUSE");
	system("CLS");

};
