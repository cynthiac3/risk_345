#include <iostream>
#include "player.h"


using namespace std;
	

Player::Player() {
	// Initialize a collection of countries that the player owns (hardcoded for assignment #1 only)
	// The coordinates of each country
	string coord1[] = { "10", "20" };
	string coord2[] = { "20", "30" };
	// The list of neighbors of each country
	vector<string> nbr1{ "USA" };
	vector<string> nbr2{ "Sweden", "Finland" };
	// Initializing the pointers to new territories objects
	Territory* t1 = new Territory("Canada", coord1, "North America", nbr1);
	Territory* t2 = new Territory("Norway", coord2, "Europe", nbr2);
	// Adding the territories to the list
	myTerritories.push_back(t1);
	myTerritories.push_back(t2);
	


	t1 = NULL;
	t2 = NULL;

	cout << "A player was created." << endl;
} 

// To be implemented in later assignments
void Player::reinforce() {
	cout << "The player is reinforcing itself." << endl;
}

// To be implemented in later assignments
void Player::attack() {
	cout << "The player is attacking." << endl;
}

// To be implemented in later assignments
void Player::fortify() {
	cout << "The player is fortifying itself." << endl;
}

// Returns the dice facility of the player
Dice Player::getDice(){
	return dice;
}

// Returns the vector holding the player's cards
vector<Deck::Cards> Player::getHand() {
	return handOfCards;
}

// Set 5 cards in the hand of the player, picked from the deck passed as a parameter
void Player::setHand(Deck theDeck) {
	handOfCards.push_back(theDeck.draw(theDeck.deck));
	handOfCards.push_back(theDeck.draw(theDeck.deck));
	handOfCards.push_back(theDeck.draw(theDeck.deck));
	handOfCards.push_back(theDeck.draw(theDeck.deck));
	handOfCards.push_back(theDeck.draw(theDeck.deck));
}

// Prints the names of the country that the player owns
void Player::getCountries() {
	if (myTerritories.size() == 0) {
		cout << "Player doesn't own any countries.";
	}
	else {
		for (int i =0; i < myTerritories.size(); i++)
			cout << "Territory #" << i+1 << ": " << myTerritories.at(i)->getName() << endl;
	}
}

// Print the cards that the player owns 
void printPlayersCards(Player p) {
	for (int i = 0; i < p.getHand().size(); i++)
	{
			switch (p.getHand()[i])
			{
				case Deck::Cards::Infantry: cout << "Card #" << i + 1 << ": Infantry" << endl; break;
				case Deck::Cards::Cavalry: cout << "Card #" << i + 1 << ": Cavalry" << endl; break;
				case Deck::Cards::Artillery: cout << "Card #" << i + 1 << ": Artillery" << endl; break;
			}
	}
}


