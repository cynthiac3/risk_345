//NEED TO ADD DESTRUCTOR!!!!!!!!!!
//

#include <vector>
#include <string>

#include "View.h"
#include "Map.h"
#include "TextTable.h"
 
using namespace std;

	
View::View(){};

View::View(Map *s){
	_subject = s;
	_subject->Attach(this);	
};

void View::Update(){
	display();	
}

void View::display(){

	int nbOfCountry = 0;
	int country[6] = {0,0,0,0,0,0};
	int armies[6] = {0,0,0,0,0,0};
	int nbOfplayer = 1;
	string current;	
	string player[6] {"1","1","1","1","1","1"}; 
	bool Notplace;
	bool complete = false;	

	vector<vertex*> info = _subject->getNodes();
	
	player[0] = (*info.begin())->owner->getName();

	for (vector<vertex*>::iterator i = info.begin() ; i != info.end(); ++i){
		
		Notplace = true;
                nbOfCountry++;
		for(int j =0; j <= nbOfplayer; j++){
			if( player[j].compare((*i)->owner->getName()) == 0){
				Notplace = false;
				armies[j] += (*i)->nbOfArmies;
				country[j] += 1;
			}else{
				if((Notplace) && (player[j].compare("1") == 0)){
					Notplace = false;
					if(nbOfplayer <5){ nbOfplayer++;}else{ complete = true; }
					player[j] = (*i)->owner->getName();
					armies[j] += (*i)->nbOfArmies;
                                	country[j] += 1;
				}
			}
		}

	}

	TextTable t( '-', '|', '+' );	

    	t.add( "Player" );
    	t.add( "Percent" );
	t.add( "Nbcountries" );
        t.add( "Nbarmies" );
    	t.endOfRow();

	if(!complete)nbOfplayer--;	

	for(int i = 0; i <= nbOfplayer; i++){
		double perc = ((double)country[i]/(double)nbOfCountry);
		t.add(player[i]);
        	t.add(to_string(perc));
		t.add(to_string(country[i]));
        	t.add(to_string(armies[i]));			
		t.endOfRow();
		//cout << "Player: " << player[i] << " percent: "<< perc <<  " number of country " << country[i] << " number of armies: " << armies[i] << endl;
	}
	
	t.setAlignment( 2, TextTable::Alignment::RIGHT );
	std::cout << t;
	cout << "\nTotal number of Country: " << nbOfCountry << endl;
}









