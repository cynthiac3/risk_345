#pragma once
#include <vector>
#include "Player.h"

// free functions declaration
void runTournament();
void clearInputsTournament();
void checkPlayersEliminatedTournament(vector<Player*> * players);
