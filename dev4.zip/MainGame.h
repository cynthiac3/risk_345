#pragma once
#include "Player.h"
#include <vector>

// free functions declaration
void runSingleGame();
void clearInputs();
void checkPlayersEliminated(vector<Player*> * players); 
