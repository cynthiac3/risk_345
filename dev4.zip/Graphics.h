#pragma once

//free functions
void riskLogo();
void empty(int lines);
void space(int lines);

void bigGame();
void bigOne();
void bigTwo();
void bigThree();
void bigFour();
void bigFive();

// If you want to "animate" the game ending, these methods build up the numbers line by line
void bigGameScrollUp();
void bigOneScrollUp();
void bigTwoScrollUp();
void bigThreeScrollUp();
void bigFourScrollUp();
void bigFiveScrollUp();

void mapBig();
