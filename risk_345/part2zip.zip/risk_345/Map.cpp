
/*
        file:Map.cpp
*/
#include <string>
#include <vector>
#include <algorithm> 
#include <iostream>
#include <stdlib.h>
#include <time.h>

#include ".\Player.h"
#include ".\Map.h"

using namespace std;
	
Map::Map(){
	//call the map loaded to load a map file.
	Map_loader m;
	
	m.parser(m.choose_file());
	//check if map is valid, verify that a territory is loaded only once
	for (vector<Territory>::iterator k  = m.myTerritories.begin() ; k != m.myTerritories.end(); ++k){
		for (vector<Territory>::iterator j  = m.myTerritories.begin() ; j != m.myTerritories.end(); ++j){
			//exit if a territory is already loaded 
			if((k->getName().compare(j->getName()) == 0)&& (k != j) ){
				cout << "Territory " << j->getName()<<" already exist, the map is invalid, program will terminate"<< endl;
				exit(0);
			}
		}
	}

	// set the map graph	
	mapG = m.map_loaded;
	
	// check if the map is connected and terminate if not
	if(!mapG.isConnected()){
		cout << "The map is not connected, program will terminat" <<endl;
		exit(0); 
        }
	
	//make the continent subgraph
	for (vector<Continent>::iterator i = m.myContinents.begin() ; i != m.myContinents.end(); ++i){
		continents_name.push_back((*i).getName());
		continents.push_back(Subgraph(m.myTerritories, (*i)));
	}
	
}

//print the map
void Map::printMap(){
	cout << "\n\nConnected: " << mapG.isConnected() <<endl;
	mapG.printGraph();
	//for (vector<Subgraph>::iterator i = continents.begin(); i != continents.end(); ++i){
	//	cout << "\n\nConnected: " << (*i).isConnected();
	//	i->printSubG();
	//} 
}

//return true if a player owns all territories 
bool Map::isOwnBy(Player *p){ 
	return mapG.isOwnBy(p);
} 
		
//Set the nb of army  on a territoriy
void Map::setNbArmies(vertex v, int nbOfA){
	mapG.setNbArmies(v, nbOfA);
}	

//return the nb of contrie of a territory
int Map::getNbofArmies(vertex v){
	return mapG.getNbofArmies(v);
}
			
//set the owner of a territory	
void Map::setOwner(vertex v, Player *p){
	mapG.setOwner(v,p);
}

//return the owner of a vertex
Player* Map::getOwner(vertex v){
	return mapG.getOwner(v);
}

//get the neighbours of a vertex
vector<vertex*> Map::getNbr(vertex v){
	return mapG.getNbr(v);
}

vertex* Map::getVertex(string name){
	return mapG.getVertex(name);
}

//testing 

void Map::setwinner(Player *p){
	mapG.setAll(p);
}

bool Map::isContOwnBy(string cont_name, Player *p){
	int index = -1;
	for(int i = 0; i < continents_name.size(); i++){
		if(cont_name.compare(continents_name[i]) == 0){
			index = i;
		}
	}
	
	if(index  == -1){
		return false;
	}else{
		return continents[index].isOwnBy(p);
	}
}


//driver for the map
int main(){
	//creats a map 
	Map map;
	
	int nbPlayer; // int to store the number of players
	bool invalid = true; // boolean use for validation
	
	Player player[nbPlayer]; // array of players 
	string tmp_name; //temporal variable to sotre a name
	
	
	srand (time(NULL)); //random input 
	int rindex; //varialbe to store a random index 
	int tmp_arr[nbPlayer]; // Temproal array to sotre index of palyers
	
	
	vector<vertex*> tmp_nodes = map.getNodes(); // list of territories to assign a them a owners
	int tmp_int=0; // temporal integer use to store a state 
	
	int order_of_play[nbPlayer];//store the order of play (each index owns a unique index(refference) to the player array)
	
	
	//prompt the user for the number player 
	cout << "Chose the number of player (2-6): ";
	
	//validate the user input 
	
	cin >> nbPlayer; // read the user input
				
	
	//read the name of each player and assign it to them
	for(int i = 0; i < nbPlayer; i++){
		cin >> tmp_name;
		player[i].setName(tmp_name);
	}
	
	
	
	
	//assign randomly contries to player in a round-robin fashion for the players
	// each player are assign to country randomly until all players have at least a coutry, then the process is repeted
	//making sure that the number of country that each players gets if equal
	for (vector<vertex*>::iterator i = tmp_nodes.begin() ; i != tmp_nodes.end(); ++i){
		do{//check if a certain player as already gone trough thi assignment round
			rindex = rand() % nbPlayer;
		}while((tmp_arr[rindex] == 1)&& !(tmp_arr[rindex] == 0));
		
		
		map.setOwner((**i), &player[rindex]); //set the owner of the current territory 
		tmp_arr[rindex] = 1; //instruct that the player x a pass is turn in that round
		tmp_int++; //increment the temporal varial use to check if all player have pass, meaning that the current round is over
	
		//if the current round is over, it resets to a new round
		if(tmp_int == nbPlayer){
			for(int i =0; i< nbPlayer; i++)tmp_arr[i] =0;
			tmp_int =0;
		}
	}
	
	
	//generate a random order_of_play 
	
	for(int i =0; i< nbPlayer; i++)tmp_arr[i] =-1;//set the temporal array to  -1 
	
	invalid = true;// reset invalid to true
	
	//generate a random order of play
	for(int i =0; i< nbPlayer; i++){
		invalid = true;
		do{
			rindex = rand() % nbPlayer;	//generate a random index 
			if(tmp_arr[i] == -1){ //check id the location available 
				invalid = false;
				for(int j =0; j<nbPlayer; j++){
					if(tmp_arr[j] == rindex)invalid = true;
				}
			}
			
		}while(invalid);
		tmp_arr[i] = rindex;
		order_of_play[i] = rindex;
	}

	
	map.printMap();
	
	int NumberOfamry;
	//switch to check the nb of army in function of the number of player
	switch(nbPlayer){
		case 2:
			NumberOfamry = 40;
			break;
		case 3: 
			NumberOfamry = 35;
			break;
		case 4:
			NumberOfamry = 30;
			break;
		case 5:
			NumberOfamry = 25;
			break;
		case 6:
			NumberOfamry = 20;
			break;
	}
	
	
	invalid = true;//reset invalid to true 
	
	//in a  round-robin fashion each player place a army on territories they owns 
	do{
		for(int i = 0; i < nbPlayer; i++){
			cout << player[order_of_play[i]].getName() << " type your territoriy that you wish to place an army on: " << endl;
			while(invalid){
				cin >> tmp_name;
			if (map.getVertex(tmp_name) == NULL){// check if the territories exist 
				cout << "This territory doesnt exist, please chose again: "  << endl;
			}
			else if( &player[order_of_play[i]] == map.getOwner(*map.getVertex(tmp_name))){ //exit loop if player owns the contry
				invalid = false;
				
			}else{
				cout << "you dont own that territory, please chose again: "  << endl; //informe the player that he does own the country
				}
			}
			invalid = true;
			map.setNbArmies(*map.getVertex(tmp_name), map.getNbofArmies(*map.getVertex(tmp_name))+1 ); // set the new amount of armies on a givien country
		}
		NumberOfamry--;
	}while(NumberOfamry != 0);

		//print the map
		map.printMap();
}
	
	






